<template>
	<view>
		<view class="uni-padding-wrap uni-common-mt">
			<movable-area scale-area>
				<movable-view direction="all" scale="true" scale-min="1" scale-max="4" scale-value="2">
					<image :src="img" mode=""></image>

					<image class="location1" src="../../static/icon/location.png" v-if="show0"></image>
					<text class="buttonstyle text1" v-if="show1" @click="clickscene(0)">滑草场</text>

					<image class="location2" src="../../static/icon/location.png" v-if="show0"></image>
					<text class="buttonstyle text2" v-if="show1" @click="clickscene(1)">海拔打卡点</text>

					<image class="location3" src="../../static/icon/location.png" v-if="show0"></image>
					<text class="buttonstyle text3" v-if="show1" @click="clickscene(2)">紫玉兰</text>

					<image class="location4" src="../../static/icon/location.png" v-if="show0"></image>
					<text class="buttonstyle text4" v-if="show1" @click="clickscene(3)">日本樱花</text>

					<image class="location5" src="../../static/icon/location.png" v-if="show0"></image>
					<text class="buttonstyle text5" v-if="show1" @click="clickscene(4)">大丽花</text>

					<image class="location6" src="../../static/icon/location.png" v-if="show0"></image>
					<text class="buttonstyle text6" v-if="show1" @click="clickscene(5)">美国紫薇</text>

					<image class="location7" src="../../static/icon/location.png" v-if="show0"></image>
					<text class="buttonstyle text7" v-if="show1" @click="clickscene(6)">索道</text>

					<image class="location8" src="../../static/icon/location.png" v-if="show0"></image>
					<text class="buttonstyle text8" v-if="show1" @click="clickscene(7)">花神阁</text>

					<image class="location9" src="../../static/icon/location.png" v-if="show0"></image>
					<text class="buttonstyle text9" v-if="show1" @click="clickscene(8)">彼岸花</text>

					<image class="location10" src="../../static/icon/location.png" v-if="show0"></image>
					<text class="buttonstyle text10" v-if="show1" @click="clickscene(9)">荷花池</text>

					<image class="location11" src="../../static/icon/location.png" v-if="show0"></image>
					<text class="buttonstyle text11" v-if="show1" @click="clickscene(10)">一品度假园</text>

					<image class="location12" src="../../static/icon/location.png" v-if="show"></image>
					<text class="buttonstyle text12" v-if="show1" @click="clickscene(11)">生态餐厅</text>

					<image class="location13" src="../../static/icon/location.png" v-if="show"></image>
					<text class="buttonstyle text13" v-if="show1" @click="clickscene(12)">牡丹商业街区</text>

					<image class="location14" src="../../static/icon/location.png" v-if="show"></image>
					<text class="buttonstyle text14" v-if="show1" @click="clickscene(13)">活动广场</text>

					<image class="location15" src="../../static/icon/location.png" v-if="show"></image>
					<text class="buttonstyle text15" v-if="show1" @click="clickscene(14)">林下花海</text>

					<image class="location16" src="../../static/icon/location.png" v-if="show"></image>
					<text class="buttonstyle text16" v-if="show1" @click="clickscene(15)">牡丹花博物馆</text>

					<image class="location17" src="../../static/icon/location.png" v-if="show"></image>
					<text class="buttonstyle text17" v-if="show1" @click="clickscene(16)">游客服务中心</text>

					<image class="location18" src="../../static/icon/location.png" v-if="show"></image>
					<text class="buttonstyle text18" v-if="show1" @click="clickscene(17)">生态停车场</text>

					<image class="location19" src="../../static/icon/gonggongcesuo.png" v-if="show2"></image>
					<text class="text19" v-if="show2">厕所</text>

					<image class="location21" src="../../static/icon/tingchechang.png" v-if="show3"></image>
					<text class="text21" v-if="show3">停车场</text>
				</movable-view>
			</movable-area>

			<van-dialog id="van-dialog" use-slot>
				<image :src="src" />
				<text style="margin-left:15px;">{{detail}}</text>
			</van-dialog>

			<text class="yuyan">语言</text>
			<image src="../../static/icon/yuyin.png" class="yuyinlogo" @click="changelang"></image>
			
			<text class="dingwei">导览</text>
			<image src="../../static/icon/miaozhun.png" class="dingweilogo" @click="getlocation"></image>
			<van-notify id="van-notify" />

			<van-popup :show="showpop" closeable close-icon="close" position="bottom" custom-style="height: 20%" @close="onClose">
				<van-radio-group :value="radio" @change="selectlang">
					<van-radio name="0" style="margin:15px 0 0 10px">御姐女声</van-radio>
					<van-radio name="3" style="margin:15px 0 0 10px">霸气男声</van-radio>
					<van-radio name="4" style="margin:15px 0 0 10px">幽默童声</van-radio>
				</van-radio-group>
			</van-popup>
		</view>

		<van-tabbar :active="active" @change="onChange">
			<van-tabbar-item icon="location-o">景点</van-tabbar-item>
			<van-tabbar-item icon="search">路线</van-tabbar-item>
			<van-tabbar-item icon="shop-o">厕所</van-tabbar-item>
			<van-tabbar-item icon="logistics">停车场</van-tabbar-item>
		</van-tabbar>
	</view>
</template>

<script>
	import Voice from '../../components/QS-baiduyy/QS-baiduyy.js';
	import Notify from '../../components/dist/notify/notify';
	import Dialog from '../../components/dist/dialog/dialog';
	export default {
		data() {
			return {
				active: 0,
				scale: 2,
				img: "https://ae01.alicdn.com/kf/H5ca744b4b1fe48989d87f90d07d2cdd9d.png",
				showpop: false,
				radio: '0',
				lang: '0',
				show0: true,
				show1: true,
				show2: false,
				show3: false,
				title: "",
				src: "",
				detail: "",
				detailcontent: [{id: 0,name: "滑草场",detail: "这里是滑草场,滑草是最近几年在国内兴起的休闲健身运动，起源于20世纪60年代的奥地利，当地的人们酷爱滑雪，但因为季节关系夏天无雪可滑。于是人们就尝试着开始滑草，希望能在草上能体验滑雪的那种愉悦和乐趣",img: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1580836775467&di=ff2e62addf9d36cd37451643ee629394&imgtype=0&src=http%3A%2F%2Fcos.solepic.com%2F20180706%2Fb_4185357_201807061150262673.jpg"},
					{id: 1,name: "海拔打卡点",detail: "这里是海拔打卡点",img: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1215322283,2010189807&fm=26&gp=0.jpg"},
					{id: 2,name: "紫玉兰",detail:"这里是紫玉兰",img: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3908404291,692201521&fm=26&gp"},
					{id: 3,name: "日本樱花",detail:"这里是日本樱花",img: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3467717833,894556390&fm=26&gp=0.jpg"},
					{id: 4,name: "大丽花",detail: "这里是大丽花",img: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1655203310,2887181523&fm=26&gp"},
					{id: 5,name: "美国紫薇",detail: "这里是美国紫薇",img: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=671883585,595426459&fm=26&gp=0.jpg"},
					{id: 6,name: "索道",detail: "这里是索道",img: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3174861139,187288849&fm=26&gp=0.jpg"},
					{id: 7,name: "花神阁",detail: "这里是花神阁",img: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2710870435,422414363&fm=26&gp=0.jpg"},
					{id: 8,name: "彼岸花",detail: "这里是彼岸花",img: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=4204725108,1395360874&fm=26&gp=0.jpg"},
					{id: 9,name: "荷花池",detail: "这里是荷花池",img: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=4195791259,115651249&fm=26&gp"},
					{id: 10,name: "一品度假园",detail: "这里是一品度假园",img: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1529657356,3869037309&fm=26&gp=0.jpg"},
					{id: 11,name: "生态餐厅",detail: "这里是生态餐厅",img: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1786811968,1728037408&fm=15&gp=0.jpg"},
					{id: 12,name: "牡丹商业街区",detail: "这里是牡丹商业街区",img: "../../static/icon/location.png"},
					{id: 13,name: "活动广场",detail: "这里是活动广场",img: "../../static/icon/location.png"},
					{id: 14,name: "林下花海",detail: "这里是林下花海",img: "../../static/icon/location.png"},
					{id: 15,name: "牡丹花博物馆",detail: "这里是牡丹花博物馆",img: "../../static/icon/location.png"},
					{id: 16,name: "游客服务中心",detail: "这里是游客服务中心",img: "../../static/icon/location.png"},
					{id: 17,name: "生态停车场",detail: "这里是生态停车场",img: "../../static/icon/location.png"}
				],

			}
		},
		methods: {
			//切换导航触发
			onChange(event) { 
				this.active = event.detail
				console.log(event.detail)

				if (this.active == 2) {
					this.show0 = false;
					this.show1 = false;
					this.show2 = true;
					this.show3 = false;
					this.img = "https://ae01.alicdn.com/kf/H5ca744b4b1fe48989d87f90d07d2cdd9d.png";


				} else if (this.active == 3) {
					this.show0 = false;
					this.show1 = false;
					this.show2 = false;
					this.show3 = true;
					this.img = "https://ae01.alicdn.com/kf/H5ca744b4b1fe48989d87f90d07d2cdd9d.png";
				} else if (this.active == 1) {
					this.img = "https://ae01.alicdn.com/kf/H0bb62a561e08488ab698fb347cbc0178u.png";
					//因为小程序不能超过2M，所以用网络图片格式
					this.show0 = false;
					this.show1 = true;
					this.show2 = false;
					this.show3 = false;
				} else {
					this.show0 = true;
					this.show1 = true;
					this.show2 = false;
					this.show3 = false;
					this.img = "https://ae01.alicdn.com/kf/H5ca744b4b1fe48989d87f90d07d2cdd9d.png";

				}
			},
			
		//点击景观触发弹框	
		clickscene(e) {
			//接收对应参数，通过参数对应数组的信息
			this.src = this.detailcontent[e].img
			this.detail = this.detailcontent[e].detail
			this.title = this.detailcontent[e].name
			Dialog.confirm({
				title: this.title,
				confirmButtonText: '解说',
				cancelButtonText: '取消',
				confirmButtonColor: '#ffef03',
				cancelButtonColor: '#756c63',
				closeOnClickOverlay: true,
		
			}).then(() => {
				this.openVoice(e); //解说的回调
			}).catch(() => {
				//取消的回调
			});
		},
		
		//调用语音
		openVoice(e) {
			// setInterval(function(){
			// console.log('准备播报语音');
			// var that =this
			//   Voice(that.detailcontent[e].detail);
			// Voice('谢谢！');
			// }, 3000)
			var that = this
			Voice({
				voiceSet: {
					tex: that.detailcontent[e].detail,
					per: this.lang
				},
				audioSet: {
					volume: 1
				},
			})
		},
		
		//改变语言抽屉框
		changelang() {
				this.showpop = true;
			},
			onClose() {
				this.showpop = false;
			},
		//选择语言
		selectlang(e) {
			this.radio = e.detail
			if (this.radio == 3) {
				this.lang = 3
			} else if (this.radio == 4) {
				this.lang = 4
			} else {
				this.lang = 0
			}
		},
		getlocation(){
				/*uni.getLocation({
				    type: 'gcj02',//wgs84不够精确
				    success: function (res) {
				        console.log('当前位置的经度：' + res.longitude);
				        console.log('当前位置的纬度：' + res.latitude);
						if(res.longitude!=0&&res.latitude!=0){
							Notify({ type: 'primary', message: '您当前不在旅游区' });
						}
						 //获取经纬度对应地理位置
						 // wx.request({
						 //          url: 'https://apis.map.qq.com/ws/geocoder/v1/',
						 //          data:{
						 //            location: `${res.latitude},${res.longitude}`,
						 //            key:"MQABZ-QF5RP-QIBDQ-LOYRE-7NFLT-TVBC4"
						 //          },
						 //          success:res=>{
						 //            console.log(res.data.result.address)
						           
						 //          }
						 //        })
				    }
				});*/
				uni.navigateTo({
					url:"../realmap/realmap"
				})
			}
		
	},
}
</script>

<style>
	movable-view {
		display: flex;
		/* align-items: center;
 	justify-content: center;  */
		width: 100vw;
		height: 100vh;
	}

	movable-area {
		height: 100vh;
		width: 100vw;
		position: fixed;
		overflow: hidden;
	}

	movable-view image {
		width: 100vw;
		height: 100vh;
	}

	.buttonstyle {
		position: absolute;
		font-size: 10px;
		border: 1px solid #c81103;
		background-color: #c81103;
		border-radius: 3px;
		color: #FFFFFF;

	}

	.location1 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 15vh;
		margin-left: 20vw;
	}

	.text1 {
		margin-top: 12.5vh;
		margin-left: 18vw;
	}

	.location2 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 27vh;
		margin-left: 33vw;
	}

	.text2 {
		margin-top: 24.5vh;
		margin-left: 29vw;
	}

	.location3 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 22vh;
		margin-left: 43vw;
	}

	.text3 {
		margin-top: 19.5vh;
		margin-left: 40vw;
	}

	.location4 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 23vh;
		margin-left: 54vw;
	}

	.text4 {
		margin-top: 20.5vh;
		margin-left: 51vw;
	}

	.location5 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 22vh;
		margin-left: 68vw;
	}

	.text5 {
		margin-top: 19.5vh;
		margin-left: 66vw;
	}

	.location6 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 18vh;
		margin-left: 83vw;
	}

	.text6 {
		margin-top: 15.5vh;
		margin-left: 80vw;
	}

	.location7 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 33vh;
		margin-left: 30vw;
	}

	.text7 {
		margin-top: 30.5vh;
		margin-left: 29vw;
	}

	.location8 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 35vh;
		margin-left: 37.5vw;
	}

	.text8 {
		margin-top: 32.5vh;
		margin-left: 35vw;
	}

	.location9 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 39vh;
		margin-left: 45.5vw;
	}

	.text9 {
		margin-top: 36.5vh;
		margin-left: 43vw;
	}

	.location10 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 36vh;
		margin-left: 72vw;
	}

	.text10 {
		margin-top: 33.5vh;
		margin-left: 70vw;
	}

	.location11 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 47.5vh;
		margin-left: 13vw;
	}

	.text11 {
		margin-top: 45vh;
		margin-left: 8vw;
	}

	.location12 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 52.5vh;
		margin-left: 19vw;
	}

	.text12 {
		margin-top: 50vh;
		margin-left: 17vw;
	}

	.location13 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 65vh;
		margin-left: 30vw;
	}

	.text13 {
		margin-top: 62.5vh;
		margin-left: 24vw;
	}

	.location14 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 57vh;
		margin-left: 36vw;
	}

	.text14 {
		margin-top: 54.5vh;
		margin-left: 32vw;
	}

	.location15 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 50vh;
		margin-left: 65vw;
	}

	.text15 {
		margin-top: 47.5vh;
		margin-left: 61vw;
	}

	.location16 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 69vh;
		margin-left: 24vw;
	}

	.text16 {
		margin-top: 66.5vh;
		margin-left: 18vw;
	}

	.location17 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 73vh;
		margin-left: 29vw;
	}

	.text17 {
		margin-top: 70.5vh;
		margin-left: 24vw;
	}

	.location18 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 82vh;
		margin-left: 19vw;
	}

	.text18 {
		margin-top: 79.5vh;
		margin-left: 14vw;

	}

	.location19 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 47.5vh;
		margin-left: 11vw;
	}

	.text19 {
		position: absolute;
		font-size: 10px;
		margin-top: 45vh;
		margin-left: 10vw;

	}

	.location21 {
		width: 10px;
		height: 10px;
		position: absolute;
		margin-top: 82vh;
		margin-left: 17vw;
	}

	.text21 {
		position: absolute;
		font-size: 10px;
		margin-top: 79.5vh;
		margin-left: 14vw;

	}

	.yuyan {
		position: absolute;
		font-size: 12px;
		margin-top: 50vh;
		width: 40px;
		height: 50px;
		text-align: center;
		line-height: 80px;
		background-color: rgba(255, 255, 255, 0.6);
	}

	.yuyinlogo {
		position: absolute;
		margin-top: 50vh;
		margin-left: 5px;
		width: 30px;
		height: 30px;
	}
	
	.dingwei {
		position: absolute;
		font-size: 12px;
		margin-top: 60vh;
		width: 40px;
		height: 50px;
		text-align: center;
		line-height: 80px;
		background-color: rgba(255, 255, 255, 0.6);
	}
	
	.dingweilogo {
		position: absolute;
		margin-top: 60vh;
		margin-left: 5px;
		width: 30px;
		height: 30px;
	}
</style>
