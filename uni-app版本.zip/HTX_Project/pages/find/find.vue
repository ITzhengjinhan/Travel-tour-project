<template>
	<view>
		<swiper class="swiper" indicator-color="rgb(255, 255, 255)" indicator-active-color="rgb(0,255,0)" :indicator-dots="indicatorDots"
		 :autoplay="autoplay" :interval="interval" :duration="duration">
			<swiper-item>
				<img src="http://tu.smyzc.com/201911/06/15730249623203046.jpg" mode="widthFix" style="border-radius: 8px;">
			</swiper-item>
			<swiper-item>
				<img src="//inews.gtimg.com/newsapp_bt/0/10019872468/1000" mode="widthFix" style="border-radius: 8px;">
			</swiper-item>
			<swiper-item>
				<img src="http://tu.smyzc.com/201911/06/15730249624221255.jpg" mode="widthFix" style="border-radius: 8px;">
			</swiper-item>
		</swiper>
		
		<van-grid column-num="4" :border="false">
			<van-grid-item use-slot wx:for-item="index">
				<image style="width: 60rpx; height: 60rpx;" src="../../static/icon/activities.png" @click="tohotactivity" />
				<text class="nag">博馆信息</text>
			</van-grid-item>
			<van-grid-item use-slot wx:for-item="index" >
				<image style="width: 60rpx; height: 60rpx;" src="../../static/icon/daolan.png"  @click="toGuildMap"/>
				<text class="nag" >景区地图</text>
			</van-grid-item>
			<van-grid-item use-slot wx:for-item="index">
				<image style="width: 60rpx; height: 60rpx;" src="../../static/icon/environment.png" @click="tocollectactivity"/>
				<text class="nag">收集活动</text>
			</van-grid-item>
			<van-grid-item use-slot wx:for-item="index">
				<image style="width: 60rpx; height: 60rpx;" src="../../static/icon/kefu.png" @click="server"/>
				<text class="nag">服务中心</text>
			</van-grid-item>
			</van-grid>
			<!-- 上拉刷新 -->
			<van-toast id="van-toast" />
			<!-- 下拉加载 -->
			<view v-for="(item,index) in imgandscrlist" :key="index">
			<img  :src="item.img"  @click=todetail(item.scene_id) style="width: 100%;height: 300rpx; border-radius: 10px">
			<view style="margin-bottom: 18px; font-size: 14px;">{{item.scene_desc}}</view>
			</view>
			<view style="text-align: center;">
			<van-loading size="24px" v-if="loading">加载中...</van-loading>
			</view>
			
	</view>
</template>

<script>
	import Toast from '../../components/dist/toast/toast';
	export default {
		onLoad() {
			this.getdata()
		},
		data() {
			return {
				indicatorDots: true,
				autoplay: true,
				interval: 2000,
				duration: 500,
				loading:false,
				imgandscrlist:'',
				
			}
		},
		onPullDownRefresh() {
			setTimeout(()=>{
			console.log(111)
			Toast("刷新成功")
			this.getdata()
			},2000)}
		,
		onReachBottom() {
			setTimeout(()=>{
			console.log(222)
			 this.loading=false
			 this.getdata()
			},2000)
			this.loading=true
			console.log(333)
			},
		
		methods: {
		toGuildMap(){
			uni.navigateTo({
				url:"../guildmap/guildmap"
			})
		},
		getdata(){
		uni.request({
		    url: 'http://39.97.116.84:3000/scene', //仅为示例，并非真实接口地址。
		    success: (res) => {
		        console.log(res.data);
		        this.imgandscrlist = res.data;
		    }
		});
		},
		todetail(e){
			console.log(e)
			uni.navigateTo({
				url:"./detail?scene_id="+e
			})
		},
		tocollectactivity(){
			uni.navigateTo({
				url:'./collectactivity'
			})
		},
		tohotactivity(){
			uni.navigateTo({
				url:'./museum_info'
			})
		},
		server(){
			uni.navigateTo({
				url:'./servercenter'
			})
		}
	}
	}
</script>

<style>
	swiper {
		width: 100%;
		height: calc(100vh*300/932);
	}

	image {
		width: 100%;
	}
</style>
