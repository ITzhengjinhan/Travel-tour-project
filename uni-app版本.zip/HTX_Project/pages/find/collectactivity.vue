<template>
	<view class="bcg">
		<view class='current_img' >
			<image v-if='img0' src="https://ae01.alicdn.com/kf/Hc8bea9786bf44d29beb0e6a51e6d5cfci.png" class='current_img'></image>
			<image v-if='model1' src="https://ae01.alicdn.com/kf/H532dfee587d7483da04096518c1ca8f8s.png" class='current_img'></image>
			<image v-if='model2' src="https://ae01.alicdn.com/kf/H5d14ce88634c4b109a4a6d47da097bf8H.png" class='current_img'></image>
			<image v-if='model3' src="https://ae01.alicdn.com/kf/H430441486dab44ffbc5757d192d93afbi.png" class='current_img'></image>
			<image v-if='model4' src="https://ae01.alicdn.com/kf/H6335f58ed949401882749f8ce6205468D.png" class='current_img'></image>
			<image v-if='model5' src="https://ae01.alicdn.com/kf/H70816b50e02a4e4eabb2b9d674673109y.png" class='current_img'></image>
			<image v-if='model6' src="https://ae01.alicdn.com/kf/H82611031c8d6445198490e21d0802da7a.png" class='current_img'></image>
			<image v-if='model7' src="https://ae01.alicdn.com/kf/Had0fcfd537924706a5c60d531731b14di.png" class='current_img'></image>
			<image v-if='model8' src="https://ae01.alicdn.com/kf/H19505bf1ad564800a74abbcdbc465bf6z.png" class='current_img'></image>
			<image v-if='model9' src="https://ae01.alicdn.com/kf/He2899827ef514dce857a22a565b9f221O.png" class='current_img'></image>
		</view>
		<view class="btn">
		<button type="primary" @click="scan" size="mini" v-if="active">扫一扫</button>
		</view>
		<view class="current_collect" >
			集齐9张，惊喜奖励等你来拿！
		</view>
				<view class="rules">
					活动规则：在以下景区会有官方的二维码，请您使用花天下景区小程序扫码激活图案，
					当您集其所有图案后，可在xxx出领取礼品，祝您旅行愉快！
				</view>
		<van-toast id="van-toast" />
	</view>
</template>

<script>
	import Toast from '../../components/dist/toast/toast.js';
	export default {
		onLoad() {
			
			this.phonenumberisexist();
			this.readcollect();
			
			
		},
		data() {
			return {
				active:true,
				img0:true,
				model1:'',
				model2:'',
				model3:'',
				model4:'',
				model5:'',
				model6:'',
				model7:'',
				model8:'',
				model9:'',
				current_num:0
			}
		},
		methods: {
			scan(){
			var that=this
			uni.scanCode({
			    success: function (res) {
					
			        console.log('条码内容：' + res.result);
					if(res.result=='请使用花天下小程序扫码#1'){
						if(that.model1=='true'){
						 Toast.success('您已激活此模块');
						}else{
						that.model1='true';
						var index=uni.getStorageSync('collectindex')
						uni.setStorageSync('collectindex',Number(index+1))
						if(index==''){
						that.isfirst()
						}else{
						that.others()
						}
						}
					}
					else if(res.result=='请使用花天下小程序扫码#2'){
						if(that.model2=='true'){
						 Toast.success('您已激活此模块');
						}else{
						that.model2='true';
						var index=uni.getStorageSync('collectindex')
						uni.setStorageSync('collectindex',Number(index+1))
						if(index==''){
						that.isfirst()
						}else{
						that.others()
						}
					}
				}
					else if(res.result=='请使用花天下小程序扫码#3'){
						if(that.model3=='true'){
						 Toast.success('您已激活此模块');
						}else{
						that.model3='true';
						var index=uni.getStorageSync('collectindex')
						uni.setStorageSync('collectindex',Number(index+1))
						if(index==''){
						that.isfirst()
						}else{
						that.others()
						}
					}
				}
					else if(res.result=='请使用花天下小程序扫码#4'){
						if(that.model4=='true'){
						 Toast.success('您已激活此模块');
						}else{
						that.model4='true';
						var index=uni.getStorageSync('collectindex')
						uni.setStorageSync('collectindex',Number(index+1))
						if(index==''){
						that.isfirst()
						}else{
						that.others()
						}
					}
				}
					else if(res.result=='请使用花天下小程序扫码#5'){
						if(that.model5=='true'){
						 Toast.success('您已激活此模块');
						}else{
						that.model5='true';
						var index=uni.getStorageSync('collectindex')
						uni.setStorageSync('collectindex',Number(index+1))
						if(index==''){
						that.isfirst()
						}else{
						that.others()
						}
					}
				}
					else if(res.result=='请使用花天下小程序扫码#6'){
						if(that.model6=='true'){
						 Toast.success('您已激活此模块');
						}else{
						that.model6='true';
						var index=uni.getStorageSync('collectindex')
						uni.setStorageSync('collectindex',Number(index+1))
						if(index==''){
						that.isfirst()
						}else{
						that.others()
						}
					}
				}
					else if(res.result=='请使用花天下小程序扫码#7'){
						if(that.model7=='true'){
						 Toast.success('您已激活此模块');
						}else{
						that.model7='true';
						var index=uni.getStorageSync('collectindex')
						uni.setStorageSync('collectindex',Number(index+1))
						if(index==''){
						that.isfirst()
						}else{
						that.others()
						}
					}
				}
					else if(res.result=='请使用花天下小程序扫码#8'){
						if(that.model8=='true'){
						 Toast.success('您已激活此模块');
						}else{
						that.model8='true';
						var index=uni.getStorageSync('collectindex')
						uni.setStorageSync('collectindex',Number(index+1))
						if(index==''){
						that.isfirst()
						}else{
						that.others()
						}
					}
				}
					else if(res.result=='请使用花天下小程序扫码#9'){
						if(that.model9=='true'){
						 Toast.success('您已激活此模块');
						}else{
						that.model9='true';
						var index=uni.getStorageSync('collectindex')
						uni.setStorageSync('collectindex',Number(index+1))
						if(index==''){
						that.isfirst()
						}else{
						that.others()
						}
						
					
				}}	
			   }
				
			});
			},
			phonenumberisexist(){
				var phonenumber=uni.getStorageSync('phonenumber')
				var wx_name=uni.getStorageSync('wx_name')
				uni.request({
				   url: 'http://39.97.116.84:3000/phonenumberisexsist?phonenumber='+phonenumber+'&&wx_name='+wx_name, //仅为示例，并非真实接口地址。
				    success: (res) => {
				       if(res.data.status=='ok'){
							return
					   }else{
						   this.active=false
						   Toast.fail('请绑定手机号')
					   }
				    }
				});
			},
			//如果用户已绑定，扫出来的第一个进行储存
			isfirst(){
				var phonenumber=uni.getStorageSync('phonenumber')
				uni.request({
				  url: 'http://39.97.116.84:3000/addcollect?model1='+this.model1+'&&model2='+this.model2+`
					&&model3=`+this.model3+'&&model4='+this.model4+'&&model5='+this.model5+`
					&&model6=`+this.model6+'&&model7='+this.model7+'&&model8='+this.model8+`
					&&model9=`+this.model9+'&&phonenumber='+phonenumber, 
				    success: (res) => {
				       if(res.data.status=='ok'){
						  
					   }else{
						  return
					   }
				    }
				});
		  },
		  others(){
			var phonenumber=uni.getStorageSync('phonenumber')
			uni.request({
			  url: 'http://39.97.116.84:3000/updatecollect?model1='+this.model1+'&&model2='+this.model2+`
				&&model3=`+this.model3+'&&model4='+this.model4+'&&model5='+this.model5+`
				&&model6=`+this.model6+'&&model7='+this.model7+'&&model8='+this.model8+`
				&&model9=`+this.model9+'&&phonenumber='+phonenumber, 
			    success: (res) => {
			       if(res.data.status=='ok'){
					   
				   }else{
					  return
				   }
			    }
			});  
		  },
		 
		  readcollect(){
			  var phonenumber=uni.getStorageSync('phonenumber')
			  var current_num=uni.getStorageSync('collectindex')
			  uni.request({
			    url: 'http://39.97.116.84:3000/collect?phonenumber='+phonenumber, 
			      success: (res) => {
			        this.model1=res.data[0].model1
					this.model2=res.data[0].model2
					this.model3=res.data[0].model3
					this.model4=res.data[0].model4
					this.model5=res.data[0].model5
					this.model6=res.data[0].model6
					this.model7=res.data[0].model7
					this.model8=res.data[0].model8
					this.model9=res.data[0].model9
					this.current_num=current_num
					console.log(res.data[0].model2)
			  	   }
			      
			  });
		  },
		  
		}
	}
</script>

<style>
.bcg{
	position: absolute;
	background-color: #E8E8E8;
	width: 100vw;
	height: 100vh;
}
.current_img{
	position: absolute;
	right: 0;
	top:6.5vh;
	left:0;
	margin: auto;
}
.current_collect,.btn{
	text-align: center;
}
.btn{
	margin-top: 2vh;
}
.rules{
	padding:0 20px;
	text-align:justify;
	margin-top:50vh
}
</style>
