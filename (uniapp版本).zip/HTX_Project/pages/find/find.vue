<template>
	<view>
		<swiper class="swiper" indicator-color="rgb(255, 255, 255)" indicator-active-color="rgb(0,255,0)" :indicator-dots="indicatorDots"
		 :autoplay="autoplay" :interval="interval" :duration="duration">
			<swiper-item>
				<img src="http://tu.smyzc.com/201911/06/15730249623203046.jpg" mode="widthFix" style="border-radius: 8px;">
			</swiper-item>
			<swiper-item>
				<img src="//inews.gtimg.com/newsapp_bt/0/10019872468/1000" mode="widthFix" style="border-radius: 8px;">
			</swiper-item>
			<swiper-item>
				<img src="http://tu.smyzc.com/201911/06/15730249624221255.jpg" mode="widthFix" style="border-radius: 8px;">
			</swiper-item>
		</swiper>
		
		<van-grid column-num="4" :border="false">
			<van-grid-item use-slot wx:for-item="index">
				<image style="width: 60rpx; height: 60rpx;" src="../../static/icon/activities.png" @click="tohotactivity" />
				<text class="nag">博馆信息</text>
			</van-grid-item>
			<van-grid-item use-slot wx:for-item="index" >
				<image style="width: 60rpx; height: 60rpx;" src="../../static/icon/daolan.png"  @click="toGuildMap"/>
				<text class="nag" >景区地图</text>
			</van-grid-item>
			<van-grid-item use-slot wx:for-item="index">
				<image style="width: 60rpx; height: 60rpx;" src="../../static/icon/environment.png" @click="tocollectactivity"/>
				<text class="nag">收集活动</text>
			</van-grid-item>
			<van-grid-item use-slot wx:for-item="index">
				<image style="width: 60rpx; height: 60rpx;" src="../../static/icon/tianqi.png" @click="totianqi"/>
				<text class="nag">天气查询</text>
			</van-grid-item>
			</van-grid>
			
			<view class="hot_scene_tab">
				<image src="../../static/icon/hot.png" style="height: 50rpx;width: 50rpx;"></image>热门活动
			</view>
			<van-grid column-num="3" gutter="15" :border="false">
				<van-grid-item use-slot wx:for-item="index">
					<image style="width: 100%; height: 90px; border-radius: 15px;" :src="hotactivity_array[0].img" @click="todetail(hotactivity_array[0].scene_id)"/>
					<text class="hot_scene_text">{{hotactivity_array[0].scene_name}}</text>
				</van-grid-item>
				<van-grid-item use-slot wx:for-item="index">
					<image style="width: 100%; height: 90px; border-radius: 15px;" :src="hotactivity_array[1].img" @click="todetail(hotactivity_array[1].scene_id)"/>
					<text class="hot_scene_text">{{hotactivity_array[1].scene_name}}</text>
				</van-grid-item>
				<van-grid-item use-slot wx:for-item="index">
					<image style="width: 100%; height: 90px; border-radius: 15px;" :src="hotactivity_array[2].img" @click="todetail(hotactivity_array[2].scene_id)"/>
					<text class="hot_scene_text">{{hotactivity_array[2].scene_name}}</text>
				</van-grid-item>
			</van-grid>
			
			<!-- 上拉刷新 -->
			<van-toast id="van-toast" />
			<!-- 下拉加载 -->
			<view v-for="(item,index) in imgandscrlist" :key="index">
			<img  :src="item.img"  @click=todetail(item.scene_id) style="width: 100%;height: 300rpx; border-radius: 10px">
			<view style="margin-bottom: 18px; font-size: 14px;">{{item.scene_desc}}</view>
			</view>
			<view style="text-align: center;">
			<van-loading size="24px" v-if="loading">加载中...</van-loading>
			</view>
			
	</view>
</template>

<script>
	import Toast from '../../components/dist/toast/toast';
	export default {
		onLoad() {
			this.gethotactivitydata()
			this.getdata()
		},
		data() {
			return {
				indicatorDots: true,
				autoplay: true,
				interval: 2000,
				duration: 500,
				loading:false,
				imgandscrlist:'',
				img1:"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1579689804143&di=55c360ca1d3f5faa0c60669bf2d96f25&imgtype=0&src=http%3A%2F%2Fd.ifengimg.com%2Fw600%2Fp0.ifengimg.com%2Fpmop%2F2018%2F0521%2FB87ACD7371C07EAE3B6A544741E6D32A7B280FC4_size47_w640_h527.jpeg",
				img2:"http://tu.smyzc.com/201911/06/15730249625243244.jpg",
				hotactivity_array:''
			}
		},
		onPullDownRefresh() {
			setTimeout(()=>{
			console.log(111)
			Toast("刷新成功")
			this.getdata()
			},2000)}
		,
		onReachBottom() {
			setTimeout(()=>{
			console.log(222)
			 this.loading=false
			 this.getdata()
			},2000)
			this.loading=true
			console.log(333)
			},
		
		methods: {
		toGuildMap(){
			uni.navigateTo({
				url:"../guildmap/guildmap"
			})
		},
		gethotactivitydata(){
			uni.request({
				 url: 'https://htxserver.xyz:3000/hotactivity',
				 success: (res) => {
				 console.log(res.data)
				this.hotactivity_array=res.data
				   },
				
			});
		},
		todetail(e){
			uni.navigateTo({
				url:"../find/detail?scene_id="+e
			})
		},
		getdata(){
		uni.request({
		    url: 'https://htxserver.xyz:3000/scene', //仅为示例，并非真实接口地址。
		    success: (res) => {
		        console.log(res.data);
		        this.imgandscrlist = res.data;
		    }
		});
		},
		todetail(e){
			console.log(e)
			uni.navigateTo({
				url:"./detail?scene_id="+e
			})
		},
		tocollectactivity(){
			uni.navigateTo({
				url:'./collectactivity'
			})
		},
		tohotactivity(){
			uni.navigateTo({
				url:'./museum_info'
			})
		},
		totianqi(){
			uni.navigateTo({
				url:'./weather'
			})
		}
	}
	}
</script>

<style>
	swiper {
		width: 100%;
		height: calc(100vh*300/932);
	}

	image {
		width: 100%;
	}
	.hot_scene_tab {
		text-align: center;
	}
	
	.hot_scene_text {
		display: flex;
		font-size: 12px;
	}
</style>
