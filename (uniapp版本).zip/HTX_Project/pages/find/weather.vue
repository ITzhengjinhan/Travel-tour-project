<template>
	<view class="container">
	  <text style="color:#007AFF">{{weather.city.text}} : {{weather.city.data}}</text>
	  <text style="color:#007AFF">{{weather.weather.text}} : {{weather.weather.data}}</text>
	  <text style="color:#007AFF">{{weather.temperature.text}} : {{weather.temperature.data}} ℃</text>
	  <text style="color:#007AFF">风速 : {{weather.winddirection.data}} {{weather.windpower.data}}</text>
	  <text style="color:#007AFF">{{weather.humidity.text}} : {{weather.humidity.data}}</text>
	</view>
</template>
 
<script>
 var amapFile = require('../../components/libs/amap-wx.js');
 var config = require('../../components/libs/config.js');
 export default {
	 onLoad(){
	    this.getdata();
	  },
	 data() {
	 	return {
	 		 weather: { city: { text: "城市", data: "获取中" }, weather: { text: "天气", data: "获取中" }, temperature: { text: "温度", data: "获取中" }, winddirection: { text: "风速", data: "获取中" }, windpower: { text: "等级", data: "获取中" }, humidity: { text: "湿度", data: "获取中" }},
	 	}
	 },
	 methods:{
		getdata(){
			var that = this;
			var key = config.Config.key;
			var myAmapFun = new amapFile.AMapWX({key: key});
			myAmapFun.getWeather({
			  success: function(data){
				console.log(data)
			     that.weather=data
			    
			  },
			  fail: function(info){
			    // wx.showModal({title:info.errMsg})
			  }
			})
		} 
	 }
	  }
</script>

<style>
	.container{
	  position: absolute;
	  top: 0;
	  bottom: 0;
	  left: 0;
	  right: 0;
	  background: url("http://img5.imgtn.bdimg.com/it/u=1747898463,3140061402&fm=26&gp=0.jpg") no-repeat;
	  background-size: 100% 100%;
	  color: #fff;
	  font-size: 18px;
	  padding-top: 200rpx;
	  padding-left: 150rpx;
	}
	.container text{
	  display: block;
	  margin: 30px;
	}
</style>
