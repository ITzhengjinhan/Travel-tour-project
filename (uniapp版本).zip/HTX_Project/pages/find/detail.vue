<template>
	<view>
		<view v-for="(item,index) in arr" :key="index">
		<image :src="item.img"  style="position: absolute;width:100%;height: 180px;"></image>
		<view class="test1">
		<view class="scene_name" >{{item.scene_name}}
		</view>
		<view class="scene_desc,font">
			{{item.scene_desc}}	
		</view>
		
		<view class="scene_addr">
		景区地址:{{item.scene_address}}<text text style="margin-left:calc(100% - 180px);">></text>	
		</view>
		</view>
		<view class="test2">
		<view class="actitime">活动时间</view>
			<view class="start_time">
			开始时间：{{item.start_time}}
			</view>
			<view class="end_time">
			结束时间：{{item.end_time}}
			</view>
		
		<view class="actiaddress">活动地点</view>
		<view class="acti_address">
			{{item.scene_address}}
		</view>
		
		<view class="actidetail">活动详情</view>
		<view class="acti_detail">
			{{item.scene_detail}}
		</view>
		</view>
		
		<view class="test3">
		<text style="margin-left: 10vw;">
			已有{{item.peoplenum}}人参加
			<text style="margin-left:25vw">上限人数：{{item.maxnumber}}</text>
		</text>
		
		<button type="primary" :disabled="isdisabled" @click="apply">{{applystatus}}</button>	
		</view>
		<van-toast id="van-toast" />
		<view class="bot">
		</view>
		
		</view>
	</view>
</template>

<script>
	import Toast from '../../components/dist/toast/toast.js';
	export default {
		onLoad:function(receive){
			console.log(receive)
			this.getdetaildata(receive)//接收传来的参数
			this.isapply()
		},
		data() {
			return {
				arr:"",
				scene_id:'',
				isdisabled:false,
				applystatus:'报名参与'
			}
		},
		methods: {
			getdetaildata(option){
			console.log(option)
			this.scene_id=option.scene_id
			uni.request({
				 url: 'https://htxserver.xyz:3000/scene?scene_id='+option.scene_id, //仅为示例，并非真实接口地址。
				 success: (res) => {
				 console.log(res.data);
				 this.arr = res.data;
				 for(var i=0;i<this.arr.length;i++){
					 if(Number(this.arr[i].peoplenum)>=Number(this.arr[i].maxnumber)){
						  console.log(111);
						 this.isdisabled=true
						 this.applystatus='人数已满'
					 }
				 }
				   }
			});
			
		},
	
		apply(){
			var phonenumber=uni.getStorageSync('phonenumber')
			if(phonenumber!='')
			{
				uni.request({
					 url: 'https://htxserver.xyz:3000/addapply?phonenumber='+phonenumber+'&&scene_id='+this.scene_id, //仅为示例，并非真实接口地址。
					 success: (res) => {
					 if(res.data.status=='ok'){
						 Toast.success('报名成功');
						 this.isdisabled=true
						 this.applystatus='已报名'
					 }else{
						 Toast.fail('请绑定手机号');
					 }
					
					   },
					
				});
			}else{
				 Toast.fail('请绑定手机号');
			}
		},
		isapply(){
			var phonenumber=uni.getStorageSync('phonenumber')
			uni.request({
				 url: 'https://htxserver.xyz:3000/isapply?phonenumber='+phonenumber+'&&scene_id='+this.scene_id, 
				 success: (res) => {
				 console.log(res.data[0].isapply)
				 if(res.data[0].isapply==1){
					 console.log('报名成功')
					 this.isdisabled=true
					 this.applystatus='已报名'
				  }else if(res.data[0].isapply==0){
					  this.isdisabled=true
					  this.applystatus='报名失败！请联系管理员'
				  }else if(this.applystatus='人数已满'){
					  console.log(222)
					  this.isdisabled=false
					  this.applystatus='人数已满'
				  }
				 else{
					 console.log(333)
					 this.isdisabled=false
					 this.applystatus='报名参与'
				 }
				   },
				
			});
			
		}
	}
}
</script>

<style>

.test1{
	position:absolute;
	margin-top: 20vh;
	margin-left: 15px;
	width:92vw;
	background-color: rgba(255,255,255,0.9);
	border-radius: 8px;
}
.scene_desc,.baoming{
	height: 5vh;
	line-height: 5vh;
	border-bottom: 2px solid #f1f1f1;
	margin-bottom: 5px;
}
.font{
	font-size: 12px;
}
.scene_addr{
	height: 5vh;
	line-height: 5vh;
}
.test2{
	position:absolute;
	margin-top: 45vh;
	margin-left: 15px;
	width:92vw;
	background-color: rgba(255,255,255,0.9);
	border-radius: 8px;
}
.actitime,.actiaddress,.actidetail{
	font-weight: bold;
	margin-top: 5px;
	margin-left: 5px;
}
.start_time,.end_time,.acti_address,.acti_detail{
	font-size:14px ;
	margin: 10px;
}
.test3{
	position:absolute;
	margin-top: 90vh;
	width:100vw;
	height: 10vh;
	background-color: rgba(255,255,255,0.9);
	line-height: 10vh;
}
.bot{
	background-color: #f1f1f1;
	height: 100vh;
	width: 100vw;
	
}
</style>
