<template>
	<view>
	
		<swiper class="swiper" indicator-color="rgb(255, 255, 255)" indicator-active-color="rgb(0,255,0)" :indicator-dots="indicatorDots"
		 :autoplay="autoplay" :interval="interval" :duration="duration">
			<swiper-item>
				<img src="http://tu.smyzc.com/201911/06/15730249623203046.jpg" mode="widthFix" style="border-radius: 8px;">
			</swiper-item>
			<swiper-item>
				<img src="https://s2.ax1x.com/2020/03/10/8COSyt.gif" mode="widthFix" style="border-radius: 8px;">
			</swiper-item>
		</swiper>
		<view class="intro">
			欢迎大家来到牡丹花博馆！
			<view class="Enter" @click="enter">
				点此进入馆内>>
			</view>
		</view>
		<view class="exhibits">
			<view class="nav">
				<view class="left">牡丹介绍</view>
				<view class="center"></view>
				<view class="right" @click="flowers_datail()">更多详情</view>
			</view>
			<scroll-view scroll-x="true" show-scollbar="true" style="white-space: nowrap;border: #808080 15px solid;padding:10px;">
				<image v-for="(item,index) in mudan_info" :key=index :src="item" style="width: 200px;height: 200px;margin-right: 10px;" @click="previewimg(item)" ></image>
				
			</scroll-view>
		</view>
		<view class="exhibits">
			<view style="margin:10px 2px 0px;border-left: #00AAFF 3px solid;">
				名画欣赏
			</view>
			<scroll-view scroll-x="true" show-scollbar="true" style="white-space: nowrap;border: #808080 20px solid;padding:10px;">
				<image v-for="(item,index) in mastergallery" :key=index :src="item" style="width: 200px;height: 200px;margin-right: 10px;" @click="previewimg1(item)" ></image>
				
			</scroll-view>
		</view>
	</view>
</template>

<script>
	export default {
		
		data() {
			return {
				indicatorDots: true,
				autoplay: true,
				interval: 2000,
				duration: 1000,
				mudan_info:['https://s2.ax1x.com/2020/03/10/8CO1kF.gif','https://s2.ax1x.com/2020/03/10/8CO61A.gif','https://s2.ax1x.com/2020/03/10/8COTpj.gif','https://s2.ax1x.com/2020/03/10/8COW0f.gif','https://s2.ax1x.com/2020/03/10/8COQTU.gif','https://s2.ax1x.com/2020/03/10/8CXe4e.gif','https://s2.ax1x.com/2020/03/10/8CObXq.gif',],
				mastergallery:['https://s2.ax1x.com/2020/03/10/8COt61.gif','https://s2.ax1x.com/2020/03/10/8COd0K.gif','https://s2.ax1x.com/2020/03/10/8COvAU.gif','https://s2.ax1x.com/2020/03/10/8CX939.gif','https://s2.ax1x.com/2020/03/10/8CXPj1.gif']
			}
		},
		methods: {
			previewimg(current){
				console.log(current)
				uni.previewImage({
					current:current,
					urls:this.mudan_info
				})
			},
			previewimg1(current){
				console.log(current)
				uni.previewImage({
					current:current,
					urls:this.mastergallery
				})
			},
			flowers_datail(){
				uni.navigateTo({
					url:"./flowers_detail"
				})
			},
			enter(){
				uni.navigateTo({
					url:"./museum_detail"
				})
			}
		}
	}
</script>

<style>
swiper {
		width: 100%;
		height: calc(100vh*300/932);
	}

	image {
		width: 100%;
	}
	.intro{
		margin-top:10px;
		color: #999999;
	}
	.Enter{
		margin-top:20px ;
		text-align: right;
		color: orange;
	}
	.nav{
		display: flex;
		text-align: center;
	}
	.nav .left {
		margin:20px 2px 0px 2px;
		border-left: #00AAFF 3px solid;
		padding-left: 10rpx;
		}
	.nav .center{
		flex: 1;
		
	}
	.nav .right{
		margin-top:20px;
		text-align: center;
		color: #999999;
	}
</style>
