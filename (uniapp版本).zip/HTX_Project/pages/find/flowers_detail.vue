<template>
		 <web-view src="http://mdy.shcmall.cn/botany.html"></web-view> 
</template>

<script>
</script>

<style>
</style>
