<template>
	<view >
		<movable-area scale-area>
			<movable-view direction="all" scale="true" scale-min="1" scale-max="4" scale-value="1">
				<image :src="bcg_img"></image>
				<image class="location1" src="../../static/icon/yuyin.png"  @click="clickscene(0)"></image>
				<image class="location2" src="../../static/icon/yuyin.png"  @click="clickscene(1)"></image>
				<image class="location3" src="../../static/icon/yuyin.png"  @click="clickscene(2)"></image>
				<image class="location4" src="../../static/icon/yuyin.png"  @click="clickscene(3)"></image>
				<image class="location5" src="../../static/icon/yuyin.png"  @click="clickscene(4)"></image>
				<image class="location6" src="../../static/icon/yuyin.png"  @click="clickscene(5)"></image>
				<image class="location7" src="../../static/icon/yuyin.png"  @click="clickscene(6)"></image>
				<image class="location8" src="../../static/icon/yuyin.png"  @click="clickscene(7)"></image>
				<image class="location9" src="../../static/icon/yuyin.png"  @click="clickscene(8)"></image>
				<image class="location10" src="../../static/icon/yuyin.png"  @click="clickscene(9)"></image>
				<image class="location11" src="../../static/icon/yuyin.png"  @click="clickscene(10)"></image>
				<image class="location12" src="../../static/icon/yuyin.png"  @click="clickscene(11)"></image>
				<image class="location13" src="../../static/icon/yuyin.png"  @click="clickscene(12)"></image>
				<image class="location14" src="../../static/icon/yuyin.png"  @click="clickscene(3)"></image>
			</movable-view>
		</movable-area>
		
		<van-dialog id="van-dialog" v-if="popchange"/>
		
		<!-- 弹出框 -->
		<van-dialog id="van-dialog" v-if="!popchange" use-slot>
			<image :src="exhibit_img" />
			<text style="margin-left:15px;">{{playlang}}</text>
		</van-dialog>
		
		<!-- 中英切换器 -->
		<view class="ch_en">
			<van-switch :checked="checked" @change="onChange"  active-color="#ee0a24" inactive-color="#07c160" size="18px" />
			<view style="font-size: 12px;">
				中&nbsp;-&nbsp;英
			</view>
		</view>
		
		
		<text class="yuyan">换语音</text>
		<image src="../../static/icon/yuyin.png" class="yuyinlogo" @click="changelang"></image>
		<van-popup :show="showpop" closeable close-icon="close" position="bottom" custom-style="height: 20%" @close="onClose">
			<van-radio-group :value="radio" @change="selectlang">
				<van-radio name="0" style="margin:15px 0 0 10px">默认女声</van-radio>
				<van-radio name="3" style="margin:15px 0 0 10px">磁性男声</van-radio>
				<van-radio name="4" style="margin:15px 0 0 10px">幽默童声</van-radio>
			</van-radio-group>
		</van-popup>
		
	</view>
</template>

<script>
	import Voice from '../../components/QS-baiduyy/QS-baiduyy.js';
	import Dialog from '../../components/dist/dialog/dialog';
	export default {
		onLoad() {
			this.getexhibit()
			this.init()
		},
		data() {
			return {
				bcg_img:'https://s1.ax1x.com/2020/04/27/Jf9ghR.jpg',
				exhibits:"",
				exhibitname: "",
				exhibit_img: "",
				exhibit_info: "",//中文
				exhibit_info_en:"",//英文
				playlang:'',//播放语言
				checked:false,//滑条默认false
				mark:0,//标记，0中文,1英文
				lang: '0',//换语音的参数
				showpop: false,//是否弹出下拉框
				radio: '0',//表示当前选中第几个
				popchange:true
			}
		},
		methods:{
			getexhibit(){
				uni.request({
					url:"https://htxserver.xyz:3000/getexhibit",
					success: (res) => {	   
						console.log(res.data)
						this.exhibits=res.data	
					}
				})
			},
			init(){
				Dialog.alert({
				  title: '帮助',
				  message:'点击地图上方语言图标可以查看详情内容；若出现无法解说现象，请您重启小程序，祝您旅行愉快！',
				}).then(() => {
				  this.popchange=false
				});
			},
			clickscene(e) {
				//接收对应参数，通过参数对应数组的信息
				this.exhibit_img = this.exhibits[e].exhibit_img
				this.exhibit_name = this.exhibits[e].exhibit_name
				console.log(this.mark)
				if(this.mark==0){
					this.playlang = this.exhibits[e].exhibit_info
				}else{
					this.playlang=this.exhibits[e].exhibit_info_en
				}
				Dialog.confirm({
					title: this.exhibit_name,
					confirmButtonText: '解说',
					cancelButtonText: '取消',
					confirmButtonColor: '#0055ff',
					cancelButtonColor: '#756c63',
					closeOnClickOverlay: true,
					asyncClose: true
				}).then(() => {
					 this.openVoice(e); //解说的回调
					 Dialog.stopLoading();//关闭加载动画
					  this.clickscene(e);//为防止关闭，再次调用弹窗
				}).catch(() => {
					Dialog.close();
					//取消的回调
				});
			},
		onChange(e) {
		   this.checked=!this.checked
		   console.log(e.detail)
		   if(e.detail==false){
			   this.mark=0
		   }else{
			   this.mark=1
		   }
		},
		openVoice(e) {
			var that = this
			console.log(that.exhibits[e].exhibit_info)
			if(this.mark==0){
				that.playlang=that.exhibits[e].exhibit_info
			}else{
				that.playlang=that.exhibits[e].exhibit_info_en
			}
			Voice({
				voiceSet: {
					tex: that.playlang,
					per: this.lang
				},
				audioSet: {
					spd:1,//语速
					volume: 1//音量
				},
				 
			})
			
		},
		//改变语言抽屉框
		changelang() {
				this.showpop = true;
			},
			onClose() {
				this.showpop = false;
			},
		//选择语言
		selectlang(e) {
			
			this.radio=e.detail
			console.log(e.detail)
			if (this.radio == 3) {
				this.lang = 3
			} else if (this.radio == 4) {
				this.lang = 4
			} else {
				this.lang = 0
			}
			
		}
	}
}
</script>

<style>
	movable-view {
		display: flex;
		/* align-items: center;
	justify-content: center;  */
		width: 100vw;
		height: 100vh;
	}
	
	movable-area {
		height: 100vh;
		width: 100vw;
		position: fixed;
		overflow: hidden;
	}
	
	movable-view image {
		width: 100vw;
		height: 100vh;
	}
	.location1 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 36vh;
		margin-left: 17vw;
	}
	.location2 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 24vh;
		margin-left: 55vw;
	}
	.location3 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 52vh;
		margin-left: 18vw;
	}
	.location4 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 48vh;
		margin-left: 28vw;
	}
	.location5 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 24vh;
		margin-left: 40vw;
	}
	.location6 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 34vh;
		margin-left: 39vw;
	}
	.location7 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 62vh;
		margin-left: 19.4vw;
	}
	.location8 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 58vh;
		margin-left: 53vw;
	}
	.location9 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 38.8vh;
		margin-left: 57vw;
	}
	.location10 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 69.5vh;
		margin-left: 49vw;
	}
	.location11 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 78vh;
		margin-left: 54vw;
	}
	.location12 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 68vh;
		margin-left: 30vw;
	}
	.location13 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 50vh;
		margin-left: 57vw;
	}
	.location14 {
		width: 30px;
		height: 30px;
		position: absolute;
		margin-top: 74vh;
		margin-left: 42vw;
	}
	.yuyan {
		position: absolute;
		font-size: 12px;
		margin-top: 10vh;
		width: 40px;
		height: 50px;
		text-align: center;
		line-height: 80px;
	
	}
	.yuyinlogo {
		position: absolute;
		margin-top: 10vh;
		margin-left: 5px;
		width: 30px;
		height: 30px;
	}
	.ch_en{
		position: absolute;
		margin-top: 2vh;
		margin-left: 5px;
	}
</style>
