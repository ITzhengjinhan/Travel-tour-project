<template>
	<view>
		<view class="my_tab_bg">
			<van-image round width="5rem" height="5rem" :src="avatarUrl" class="userimg" />
			<view class="userinfo">
				{{nickNames}}
			</view>
			<view class="editinfo" @click="editinfo" v-if="editinfobutton">
				{{bindorupdata}}
			</view>
			<button class='getuserinfo'
			 lang="zh_CN"
			 open-type="getUserInfo" 
			 
			 @getuserinfo="getuserinfo" 
			 withCredentials="true"
			 size="mini"
			 v-if="isNotagree"
			 >
				获取微信用户信息
			</button>
		</view>
		
		<view class="section">
		
		<view class="my_sth">
		<view class="mycollect" style="background-color: #FFFFFF;height:44px;width: 100%;line-height: 44px;display: flex;" @click="navigateToapply()">
			<text style="flex: 1;margin-left: 20px;">我的报名</text><text style="flex: 1;text-align: right;margin-right: 20px; color:#999999">></text>
		</view>
		<view class="mycollect" style="background-color: #FFFFFF;height:44px;width: 100%;line-height: 44px;display: flex;">
			<text style="flex: 1;margin-left: 20px;">我的收藏</text><text style="flex: 1;text-align: right;margin-right: 20px; color:#999999">></text>
		</view>
		<view class="mycollect" style="background-color: #FFFFFF;height:44px;width: 100%;line-height: 44px;display: flex;">
			<text style="flex: 1;margin-left: 20px;">我的消息</text><text style="flex: 1;text-align: right;margin-right: 20px; color:#999999">></text>
		</view>
		<view class="mycollect" style="background-color: #FFFFFF;height:44px;width: 100%;line-height: 44px;display: flex;" @click="navigateToabout()">
			<text style="flex: 1;margin-left: 20px;">关于我们</text><text style="flex: 1;text-align: right;margin-right: 20px; color:#999999">></text>
		</view>
		
		</view>
		</view>
	</view>
</template>

<script>
	export default {
		onLoad(){
			
			var nickNames=uni.getStorageSync('wx_name')
			var avatarUrl=uni.getStorageSync('wx_avatarUrl')
				
			if(nickNames!=''&&avatarUrl!=''){
				this.nickNames=nickNames
				this.avatarUrl=avatarUrl
				this.isNotagree=false
				this.editinfobutton=true
				
			}else{
				this.nickNames='匿名用户'
				this.avatarUrl='https://img.yzcdn.cn/vant/cat.jpeg'
				this.isNotagree=true
				this.editinfobutton=false
			}
			this.isexist();
		},
		
		data() {
			return {
				
				nickNames: '匿名用户',
				avatarUrl: 'https://img.yzcdn.cn/vant/cat.jpeg',
				editinfobutton:true,
				isNotagree:'true',
				gender:'',
				province:'',
				city:'',
				bindorupdata:""
			}
		},

		methods: {
			getuserinfo() {
				let that = this
				uni.login({
					success: function(loginRes) {
						console.log(loginRes)
						// 获取用户信息
						uni.getUserInfo({
							lang:'zh_CN',
							success: function(infoRes) {
								that.nickNames = infoRes.userInfo.nickName;
								that.avatarUrl = infoRes.userInfo.avatarUrl;
								that.gender=infoRes.userInfo.gender;
								if(that.gender==1){
									that.gender='男'
								}
								else if(that.gender==2){
									that.gender='女'
								}
								that.province=infoRes.userInfo.province
								that.city=infoRes.userInfo.city
								that.isNotagree=false;
								that.editinfobutton=true;
								uni.setStorageSync('wx_name',that.nickNames),
								uni.setStorageSync('wx_avatarUrl',that.avatarUrl)
								uni.setStorageSync('wx_gender',that.gender)
								uni.setStorageSync('wx_address',that.province+that.city)
							}
						});
						
					}
				});
				
			},
			isexist(){
				var phonenumber=uni.getStorageSync('phonenumber')
				if(phonenumber==''||phonenumber==null){
					this.bindorupdata="绑定手机号"
				}else{
					this.bindorupdata="更改手机号"
				}
			},
			editinfo(){
				uni.navigateTo({
					url:"./editInfo"
				})
			},
			navigateToapply(){
				uni.navigateTo({
					url:"./apply"
				})
			},
			navigateToabout(){
				uni.navigateTo({
					url:"./servercenter"
				})
			}
		}
	}
</script>

<style>
	.my_tab_bg {
		height: 160px;
		width: 100%;
		background: -webkit-linear-gradient(left, white, #00aaff);
	}
	.section{
		background-color: #FF0000;
		
	}
	.userimg {
		position: absolute;
		margin-top: 30px;
		margin-left: 10px;
	}

	.userinfo {
		position: absolute;
		margin-top: 40px;
		margin-left: 120px;
		color: white;
	}

	.editinfo {
		position: absolute;
		margin-top: 75px;
		margin-left: 115px;
		color: white;
	}
	.getuserinfo{
		position: absolute;
		margin-top: 105px;
		margin-left: 115px;
	}
	
	.van-panel__header-value{
		color:#999999;
		color:var(--panel-header-value-color,#999999)
	}
	
	
	.section{
		background-color: #e8e8e8;
		width: 100vw;
		height: 100vh;
	}
</style>
