<template>
	<view>
	<view v-for="(item,index) in arr" :key="index" @click=todetail(item.scene_id)>
		<van-card 
		  :desc=item.scene_desc
		  :title=item.scene_name
		  :thumb=item.img
		>
		 <view slot="footer">
		    <van-button color="linear-gradient(to right, #4bb0ff, #6149f6)" :disabled="item.isapply=='报名失败'?true:false" @click="cancelapply(item.scene_id)">{{item.isapply}}</van-button>
			</view>
		</van-card>
		
		<view style="border-top: #ffffff 2px solid;"></view>
	
	</view>
	<van-toast id="van-toast" />
  </view>
</template>

<script>
	import Toast from '../../components/dist/toast/toast.js';
	export default {
	onLoad(){
		this.isexist();
		
	},
	
	data(){
		return{
			arr:'',
			mark:'',
			status:'',
			btnstatus:''
		}
	},
	methods:{
		//判断是否绑定手机号
		isexist(){
			var phonenumber=uni.getStorageSync('phonenumber')
			if(phonenumber==''||phonenumber==null){
				this.exit()
			}else{
				this.getdata()
			}
		},
		//请求数据
		getdata(){
			var  phonenumber=uni.getStorageSync('phonenumber')
			
			uni.request({
				url: 'https://htxserver.xyz:3000/queryapply?phonenumber='+phonenumber,
				success: (res) => {
				    console.log(res.data);
				    this.arr=res.data
				}
			})
		},
		
		//退回到‘我的’页面
		exit(){
			setTimeout(()=>{
				uni.switchTab({
					url:"./my"
				})
			},2000)
			Toast.fail('请绑定手机号')
		},
		cancelapply(e){
			this.mark=1;
			console.log(e)
			var scene_id=e;
			var phonenumber=uni.getStorageSync('phonenumber')
			uni.request({
				url: 'https://htxserver.xyz:3000/deleteapply?phonenumber='+phonenumber+'&&scene_id='+scene_id,
				success: (res) => {
				    console.log(res.data);
				    if(res.data.status=='ok'){
						setTimeout(()=>{
							//类似Location.reload()方法
							let pages=getCurrentPages();
							let page=pages[pages.length-1];
							page.onLoad()
						},1000)
						Toast.success('取消成功')
					}else{
						Toast.fail('取消失败，请重试')
					}
				}
			})
		},
		todetail(e){
			if(this.mark!=1){
			setTimeout(()=>{
				console.log(e)
				uni.navigateTo({
					url:"../find/detail?scene_id="+e
				})
			},500)
			}
		}
	},
}
</script>

<style>
</style>
