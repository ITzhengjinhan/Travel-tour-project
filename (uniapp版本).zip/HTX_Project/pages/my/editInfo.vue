<template>
	<view>
		<view style="text-align: center;">
		<van-image round width="5rem" height="5rem" :src="wx_avatarUrl"  />
		</view>
		<van-cell-group>
			<van-field readonly label="微信名" icon="success" :value="wx_name" />

			<van-field readonly label="性别" icon="success" :value="wx_gender" />

			<van-field readonly label="地址" icon="success" :value="wx_address" />

			<van-field required label="手机号码" :value='phone' @change=test1  placeholder="请输入手机号码" @blur='phonetest'
			 :error-message="error_message" />
			<van-field center clearable :value='code' @change="test" label="短信验证码" placeholder="请输入短信验证码" :border="false"
			 use-button-slot>
				<van-button slot="button" size="small" type="primary" @click="getCode" :disabled="getcodebutishow">{{send}}</van-button>
			</van-field>
		</van-cell-group>
		<button type="primary" @click="keep" :disabled="bindbutisnotshow">{{bindstatus}}</button>
		<van-toast id="van-toast" />
	</view>
</template>

<script>
	import zhenzisms from '../../components/utils/zhenzisms.js';
	import Toast from '../../components/dist/toast/toast.js';
	export default {
		onLoad(){
			var wx_avatarUrl=uni.getStorageSync('wx_avatarUrl')
			var wx_name=uni.getStorageSync('wx_name')
			var wx_gender=uni.getStorageSync('wx_gender')
			var wx_address=uni.getStorageSync('wx_address')
			var phonenumber=uni.getStorageSync('phonenumber')
			this.wx_name=wx_name;
			this.wx_gender=wx_gender;
			this.wx_address=wx_address;
			this.phone=phonenumber;
			this.wx_avatarUrl=wx_avatarUrl
			uni.request({
				//39.97.116.84:3000
			    url: 'https://htxserver.xyz:3000/phonenumberisexsist?phonenumber='+phonenumber+'&&wx_name='+wx_name, //仅为示例，并非真实接口地址。
			    success: (res) => {
			       if(res.data.status=='ok'){
						this.bindbutisnotshow=true
						this.bindstatus="已绑定"
						this.getcodebutishow=true
						console.log(res.data.status)
				   }else{
					   console.log(111)
				   }
			    }
			});
		},
			onUnload() {
				wx.reLaunch({
					url:"./my"
				})
			},
		data() {
			return {
				wx_avatarUrl:'',
				wx_name:'',
				wx_gender:'',
				wx_address:'',
				bindbutisnotshow:false,
				bindstatus:'绑定',
				error_message: '',
				flag: 0,
				phone: '',
				code: '',
				send: '获取验证码',
				getcodebutishow: false
			}
		},
		methods: {
			//失去焦点时，通过正则表达式验证手机号
			phonetest(event) {
				var wx_name=uni.getStorageSync('wx_name')
				console.log(event.detail)
				if (!(/^[1][3,4,5,7,8][0-9]{9}$/.test(event.detail.value))) {
					this.error_message = '请输入正确手机号'
				} else {
					this.error_message = ''
				}
				uni.setStorageSync('phonenumber',event.detail.value)
				uni.request({
				    url: 'https://htxserver.xyz:3000/phonenumberisexsist?phonenumber='+uni.getStorageSync('phonenumber')+'&&wx_name='+wx_name, //仅为示例，并非真实接口地址。
				    success: (res) => {
				       if(res.data.status=='ok'){
							this.bindbutisnotshow=true
							this.bindstatus="已绑定"
							this.getcodebutishow=true
							console.log(res.data.status)
					   }else{
						   this.bindbutisnotshow=false
						   this.bindstatus="绑定"
						   this.getcodebutishow=false
						   console.log(111)
						   uni.removeStorageSync('phonenumber')
					   }
				    }
				});
				
				
			},
			//点击按钮时定时60s，开始倒计时
			sendcode() {
				let self = this
				//验证码
				self.getcodebutishow = true;
				var time = 60; //时间为10s，可以按情况更改 
				var timer = setInterval(fun, 1000); //设置定时器 
				function fun() {
					time--;
					if (time >= 0) {
						self.send = time + "s后重新发送";
					} else if (time < 0) {
						self.send = "重新发送验证码";
						self.getcodebutishow = false; //倒计时结束能够重新点击发送的按钮 
						clearInterval(timer); //清除定时器 
						time = 60; //设置循环重新开始条件 
					}
				}
			},
			//获取验证码
			getCode(e) {
				this.sendcode();
				var that = this;
				zhenzisms.client.init('https://sms_developer.zhenzikj.com', '104492', '2d55648b-5733-41ba-99f9-c9dee23c6e37');
				var params = {};
				params.number = that.phone;
				params.message = '您好！欢迎您来到武洋花天下景区，您的验证码为:{code}';
				params.seconds = 60 * 5;
				params.length = 6;
				// params.messageId = '1111111';
				// params.clientIp = '221.221.221.111';
				zhenzisms.client.sendCode(function(res) {}, params);
			},
			//点击保存按钮
			keep() {
				var result = zhenzisms.client.validateCode(this.phone, this.code);
				
				if (result == 'ok') {
					uni.setStorageSync('phonenumber',this.phone)
					uni.request({
					    url: "https://htxserver.xyz:3000/adduser?phonenumber="+this.phone+'&&wx_name='+this.wx_name+"&&wx_gender="+this.wx_gender+"&&wx_address="+this.wx_address, 
					 		 success: (res) => {
					 		 console.log(res.data)
							
					 		   },
							
					 	});
					setTimeout(()=>{
						uni.switchTab({
							url:'../my/my'
						})
					},3000)
					Toast.success('保存成功');
				} else if (result == 'code_error') {
					Toast.fail('验证错误，验证码不一致!');

				} else if (result == 'code_expired') {
					Toast.fail('验证错误，验证码已过期!');

				}

			},
			//获取输入的验证码，赋值于code
			test(e) {
				console.log(e.mp.detail)
				this.code = e.mp.detail
			},
			//获取输入的手机号，赋值于phone
			test1(e) {
				this.phone = e.mp.detail
			}
		}
	}
</script>

<style>

</style>
