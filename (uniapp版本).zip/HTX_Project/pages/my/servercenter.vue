<template>
	<view class="bcg">
		<view class="outborder">
			<view class="lyzx_phone">
				旅游咨询电话
				<button type="warn" size='mini' style="position: absolute;margin-top: 1vh;margin-left: 40vw;" @click="call1">拨号</button>
			</view>
			<view class="lyzx_phonenumber">
				0598-6223223
			</view>
		</view>
		
		 <view class="outborder">
			<view class="lyjb_phone">
				旅游举报电话
				<button type="warn" size='mini' style="position: absolute;margin-top: 1vh;margin-left: 40vw;"@click="call2">拨号</button>
			</view>
			<view class="lyzx_phonenumber">
				0598-6223273
			</view>
		</view> 
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			call1(){
				uni.makePhoneCall({
				    phoneNumber: '0598-6223223' //仅为示例
				});
			},
			call2(){
				uni.makePhoneCall({
				    phoneNumber: '0598-6223273' //仅为示例
				});
			}
		}
	}
</script>

<style>
.outborder{
	
	border-radius: 5px;
	border: #F8F8F8 solid 2px;
	background-color: #FFFFFF;
	width: 90%;
	margin:5vh 2vw 0 4vw;
	}
.bcg{
	position: absolute;
	background-color: #D4D4D4;
	width: 100vw;
	height: 100vh;
}
.lyzx_phone,.lyjb_phone{
	margin: 2vh 3vw 1vh;
}
.lyzx_phonenumber,.lyzx_phonenumber{
	margin-left:3vw ;
	margin-bottom: 2vh;
	font-size: 14px;
}
</style>
