<template>
	<view>
		<view class="btn" @click="openMap">打开地图</view>
	</view>
</template>

<script>
	import Map from '../../components/ms-openMap/openMap.js'
	
	export default {
		
		data() {
			return {
				latitude:'',
				longitude:'',
				name:'福州'
			}
		},
		methods: {
			openMap() {
				var that=this
				uni.getLocation({
				    type: 'gcj02',//wgs84不够精确
				    success: function (res) {
				        console.log('当前位置的经度：' + res.longitude);
				        console.log('当前位置的纬度：' + res.latitude);
						that.longitude=res.longitude;
						that.latitude=res.latitude;
						
						wx.request({
						         url: 'https://apis.map.qq.com/ws/geocoder/v1/',
						         data:{
						           location: `${res.latitude},${res.longitude}`,
						           key:"MQABZ-QF5RP-QIBDQ-LOYRE-7NFLT-TVBC4"
						         },
						         success:res=>{
						           console.log(res.data.result.address)
								   that.name=res.data.result.address
						          
						         }
						       })
							  }
						})
				Map.openMap(that.latitude, that.longitude, that.name, 'gcj02')
			}
		}
	}
</script>

<style lang="scss">
	.btn {
		padding: 15px;
		margin: 10px;
		box-shadow: 0 1px 5px #ebedf0;
	}

</style>

