<template>
	<view>
		<image src="http://tu.smyzc.com/201911/06/15730249625243244.jpg" style="height: 300rpx;width: 100%;"></image>
		
		<view class="hot_scene_tab">
			<image src="../../static/icon/hot.png" style="height: 50rpx;width: 50rpx;"></image>必游景点
		</view>

		<van-grid column-num="3" gutter="15" :border="false">
			<van-grid-item use-slot wx:for-item="index" >
				<image style="width: 100%; height: 90px; border-radius: 15px;" src="https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2710870435,422414363&fm=26&gp=0.jpg" @click="tohotscenic()"/>
				<text class="hot_scene_text">花神阁</text>
			</van-grid-item>
			<van-grid-item use-slot wx:for-item="index">
				<image style="width: 100%; height: 90px; border-radius: 15px;" src="http://tu.smyzc.com/201911/06/15730249623203046.jpg" @click="tohotscenic()"/>
				<text class="hot_scene_text">牡丹花博馆</text>
			</van-grid-item>
			<van-grid-item use-slot wx:for-item="index">
				<image style="width: 100%; height: 90px; border-radius: 15px;" src="https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=671883585,595426459&fm=26&gp=0.jpg" @click="tohotscenic()"/>
				<text class="hot_scene_text">林下花海</text>
			</van-grid-item>
		</van-grid>
		<view class="hot_scene_tab">
			<image src="../../static/icon/hot.png" style="height: 50rpx;width: 50rpx;"></image>热门活动
		</view>
		
		<van-grid column-num="3" gutter="15" :border="false">
			<van-grid-item use-slot wx:for-item="index">
				<image style="width: 100%; height: 90px; border-radius: 15px;" :src="hotactivity_array[0].img" @click="todetail(hotactivity_array[0].scene_id)"/>
				<text class="hot_scene_text">{{hotactivity_array[0].scene_name}}</text>
			</van-grid-item>
			<van-grid-item use-slot wx:for-item="index">
				<image style="width: 100%; height: 90px; border-radius: 15px;" :src="hotactivity_array[1].img" @click="todetail(hotactivity_array[1].scene_id)"/>
				<text class="hot_scene_text">{{hotactivity_array[1].scene_name}}</text>
			</van-grid-item>
			<van-grid-item use-slot wx:for-item="index">
				<image style="width: 100%; height: 90px; border-radius: 15px;" :src="hotactivity_array[2].img" @click="todetail(hotactivity_array[2].scene_id)"/>
				<text class="hot_scene_text">{{hotactivity_array[2].scene_name}}</text>
			</van-grid-item>
		</van-grid>
		<view class="shopping">
			<view class="left">店铺</view>
			<view class="center"></view>
			<view class="right">更多 》</view>
		</view>
		<van-card 
		  desc="菜品种类丰富"
		  title="店铺一"
		  :thumb="img1">
		 <view slot="bottom" class="scoreandaveprice">
		    <text class="score">4.1分</text>
			<text class="aveprice">人均：<text>78.00</text></text>
		  </view>
		  </van-card>
		<van-card
		  desc="欢迎光临本店"
		  title="店铺二"
		  :thumb="img2">
		 <view slot="bottom" class="scoreandaveprice">
		    <text class="score">3.5分</text>
			<text class="aveprice">人均：<text>58.00</text></text>
		  </view>
		  </van-card>
		  
		  <view class="shopping">
		  	<view class="left">住宿</view>
		  	<view class="center"></view>
		  	<view class="right">更多 》</view>
		  </view>
		  <van-card
		    desc="菜品种类丰富"
		    title="店铺一"
		    :thumb="img1">
		   <view slot="bottom" class="scoreandaveprice">
		      <text class="score">4.1分</text>
		  	<text class="aveprice">人均：<text>78.00</text></text>
		    </view>
		    </van-card>
			
	</view>
</template>

<script>
	
	
	export default {
		onLoad() {
			this.gethotactivitydata()
		},
		data() {
			return {
				img1:"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1579689804143&di=55c360ca1d3f5faa0c60669bf2d96f25&imgtype=0&src=http%3A%2F%2Fd.ifengimg.com%2Fw600%2Fp0.ifengimg.com%2Fpmop%2F2018%2F0521%2FB87ACD7371C07EAE3B6A544741E6D32A7B280FC4_size47_w640_h527.jpeg",
				img2:"http://tu.smyzc.com/201911/06/15730249625243244.jpg",
				hotactivity_array:''
			}
		},
		methods: {
			gethotactivitydata(){
				uni.request({
					 url: 'https://htxserver.xyz:3000/hotactivity',
					 success: (res) => {
					 console.log(res.data)
					this.hotactivity_array=res.data
					   },
					
				});
			},
			todetail(e){
				uni.navigateTo({
					url:"../find/detail?scene_id="+e
				})
			},
			//tohotscenic(){
				//uni.navigateTo({
					//url:"./hotscenic"
				//})
			//}
		}
	}
</script>

<style>
	.nag {
		font-size: 12px;
		margin-top: 5px;
	}

	.hot_scene_tab {
		text-align: center;
	}

	.hot_scene_text {
		display: flex;
		font-size: 12px;
	}
	.shopping{
		display: flex;
		text-align: center;
	}
	.shopping .left {
		border-left: 5rpx solid #007AFF;
		margin-left: 8rpx;
		padding-left: 10rpx;
		}
	.shopping .center{
		flex: 1;
		
	}
	.shopping .right{
		text-align: right;
		color: #999999;
	}
	.scoreandaveprice{
		margin-top:50rpx
	}
	.scoreandaveprice .score{
		color: red;
	}
	.aveprice{
		margin-left:35vw;
		color:#999999
	}
	.van-card__img {
		border-radius: 20px;
	}	
</style>
