//index.js
//获取应用实例
Page({

  /**
   * 页面的初始数据
   */
  data: {

    movies: [
      { url: 'http://mdy.shcmall.cn/img/scenic_detail/6.png' },
      { url: 'http://mdy.shcmall.cn/img/scenic_detail/5.png' },
      { url: 'http://mdy.shcmall.cn/img/scenic_detail/5-2.png' }

    ],
  },

  click: function (e) {
    wx.navigateTo({
      url: '../luxian/luxian',
    })
  },
  click2: function (e2) {
    wx.navigateTo({
      url: '../fuwu/fuwu',
    })
  },
  click1: function (e1) {
    wx.navigateTo({
      url: '../fuwu01/fuwu01',
    })
  },
  click0: function (e0) {
    wx.navigateTo({
      url: '../fuwu02/fuwu02',
    })
  },
  click3: function (e3) {
    wx.navigateTo({
      url: '../fuwu03/fuwu03',
    })
  }
})