// pages/fuwu/fuwu.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    movies: [
      { url: 'http://mdy.shcmall.cn/img/flow/21.png' },
      { url: 'http://mdy.shcmall.cn/img/flow/12-1.jpg' },
      { url: 'http://mdy.shcmall.cn/img/flow/15-1.jpg' }
      
    ],
    

    

    
  },
  one:function(){
    wx.navigateTo({
      url: '../login/login',
    })
  },
  two: function () {
    wx.navigateTo({
      url: '../huawang/huawang',
    })
  },
  seven: function (){
    wx.navigateTo({
      url: '../fuwu03/fuwu03',
    })
  },
  three: function () {
    wx.navigateTo({
      url: '../luxian/luxian',
    })
  },
  four: function () {
    wx.navigateTo({
      url: '../fuwu01/fuwu01',
    })
  },
  five: function () {
    wx.navigateTo({
      url: '../fuwu02/fuwu02',
    })
  },
  six: function () {
    wx.navigateTo({
      url: '../zaipei/zaipei',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})