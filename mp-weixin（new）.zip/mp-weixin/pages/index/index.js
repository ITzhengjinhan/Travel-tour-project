//index.js
//获取应用实例
Page({

  /**
   * 页面的初始数据
   */
  data: {
    
    movies: [
      { url: 'https://s1.ax1x.com/2020/05/16/Y6KLxf.jpg' },
      { url: 'https://s1.ax1x.com/2020/05/16/Y6KbGt.jpg' },
      { url: 'http://mdy.shcmall.cn/img/scenic_detail/6.png' }

    ],
  },

  click:function(e){
     var nickNames = wx.getStorageSync('wx_name');
     if(nickNames!=''){
      wx.navigateTo({
        url: '../luxian/luxian',
       })
     }else{
      

         wx.showToast({

           title: '请前往个人页面登入',

          icon: 'none'

         })
    }
    
  },
  click2:function(e2){
    var nickNames = wx.getStorageSync('wx_name');
    console.log(nickNames);
    if (nickNames!= '') {
      wx.navigateTo({
        url: '../fuwu/fuwu',
      })
    } else {
      wx.showToast({

        title: '请前往个人页面登入',

        icon: 'none'

      })
    }
   
  },
  click1: function (e1) {
    var nickNames = wx.getStorageSync('wx_name');
    console.log(nickNames);
    if (nickNames!= '') {
      wx.navigateTo({
        url: '../fuwu01/fuwu01',
      })
    } else {
      wx.showToast({

        title: '请前往个人页面登入',

        icon: 'none'

      })
    }
   
  },
  click0: function (e0) {
    var nickNames = wx.getStorageSync('wx_name');
    console.log(nickNames);
    if (nickNames!= '') {
      wx.navigateTo({
        url: '../fuwu02/fuwu02',
      })
    } else {
      wx.showToast({

        title: '请前往个人页面登入',

        icon: 'none'

      })
    }

   
  },
  click3: function (e3) {
    var nickNames = wx.getStorageSync('wx_name');
    console.log(nickNames);
    if (nickNames!= '') {
      wx.navigateTo({
        url: '../fuwu03/fuwu03',
      })
    } else {
      wx.showToast({

        title: '请前往个人页面登入',

        icon: 'none'

      })
    }
    

   
  },
  huasuo03: function (e4) {
     var nickNames = wx.getStorageSync('wx_name');
     if (nickNames!= '') {
      wx.navigateTo({
        url: '../huasuo/hausuo',
      })
     } else {
       wx.showToast({

         title: '请前往个人页面登入',

         icon: 'none'

       })
     }
  },
  click5:function(){
    var nickNames = wx.getStorageSync('wx_name');
    if (nickNames != '') {
    wx.navigateTo({
      url: '../huacao/huacao',
    })
    } else {
      wx.showToast({

        title: '请前往个人页面登入',

        icon: 'none'

      })
    }
  },
  

})