const app = getApp()
Page({
  data: {
  },
  onLoad: function () {
    var self = this;
    this.mapCtx = wx.createMapContext('myMap');
    wx.getLocation({
      type: 'gcj02',
      success(res) {
        self.setData({
          latitude: res.latitude,
          longitude: res.longitude,

          markers: [{
            id: 1,
            latitude: 26.213686,
            longitude: 118.555913,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "一品红\r\n游玩时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 2,
            latitude: 26.213508,
            longitude: 118.555736,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "活动广场\r\n游玩时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            },

          },
          {
            id: 3,
            latitude: 26.213234,
            longitude: 118.555307,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "服务点: 停车场\r\n内容: 停放车辆\r\n",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 4,
            latitude: 26.213369,
            longitude: 118.555318,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "花博馆\r\n游玩时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 5,
            latitude: 26.213422,
            longitude: 118.555543,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "牡丹商业园\r\n游玩时间：3小时\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 6,
            latitude: 26.213253,
            longitude: 118.555564,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "服务中心\r\n时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 7,
            latitude: 26.213686,
            longitude: 118.555178,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "生态餐厅\r\n时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 8,
            latitude: 26.213811,
            longitude: 118.555017,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "一品度假园\r\n时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 9,
            latitude: 26.213768,
            longitude: 118.555543,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "花神阁\r\n开放时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 10,
            latitude: 26.213754,
            longitude: 118.555350,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "索道\r\n游玩时间：2小时\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 11,
            latitude: 26.213912,
            longitude: 118.555328,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "海拔打卡点\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 12,
            latitude: 26.214086,
            longitude: 118.555049,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "滑草\r\n开放时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 13,
            latitude: 26.214076,
            longitude: 118.555484,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "乌龙捧盛\r\n开放时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 14,
            latitude: 26.214091,
            longitude: 118.555741,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "玉楼春\r\n开放时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 15,
            latitude: 26.214249,
            longitude: 118.555908,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "红宝石\r\n开放时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },

          {
            id: 16,
            latitude: 26.213898,
            longitude: 118.556546,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "雁落粉荷\r\n开放时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },

          {
            id: 17,
            latitude: 26.213821,
            longitude: 118.556294,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "荷花池\r\n开放时间：全天\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          },
          {
            id: 18,
            latitude: 26.213397,
            longitude: 118.556117,
            iconPath: 'https://s1.ax1x.com/2020/05/16/Y6Hs0A.png',
            width: 30,
            height: 30,
            callout: {
              content: "林下花海\r\n游玩时间：3小时\r\n客服电话：0591 - 87675791",
              bgColor: "#fff",
              padding: "5px",
              borderRadius: "2px",
              borderWidth: "1px",
              borderColor: "#07c160",

            }
          }
          ],
        });
      }
    })
  },
})