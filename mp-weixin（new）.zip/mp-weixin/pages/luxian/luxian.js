// pages/luxian/luxian.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    active: 0,
    

  },
  
  btn01:function(){
    wx.navigateTo({
      url: '../pingjia/pingjia',
    })
  },
  realview01:function(){
    wx.navigateTo({
      url: '../realview01/realview01',
    })

  },
  pingjia:function(){
    wx.navigateTo({
      url: '../pinjia/pinjia',
    })
  }

  /**
   * 生命周期函数--监听页面加载
   */
  
})